#!/usr/bin/env python3
"""Deterministic sector-aware scorer for Shri's Stock Brain.

The script intentionally separates philosophy fit from fundamental quality.
It never fetches data and never interprets a missing value as zero.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = "1.0"
DISCLAIMER = (
    "Educational research aid only. This score is not personalised investment "
    "advice, a recommendation to transact, or a forecast of returns."
)

SECTOR_NEIGHBORS = {
    "bank": ["The Karnataka Bank", "Tamilnad Mercantile Bank", "State Bank of India"],
    "nbfc": ["Cholamandalam Investment and Finance", "L&T Finance"],
    "infrastructure": ["IRB Infrastructure Developers", "Ashoka Buildcon", "Tata Power"],
    "power": ["Tata Power", "ONGC"],
    "pharma": ["Cipla", "Dr. Reddy's Laboratories"],
    "cyclical": ["Tata Steel", "ONGC", "Great Eastern Shipping (historical pick)"],
    "auto": ["Tata Motors Passenger Vehicles"],
    "real_estate": ["Valor Estate", "Advent Hotels International"],
    "hospitality": ["Advent Hotels International", "Valor Estate"],
    "generic": [],
}

SECTOR_REQUIRED = {
    "bank": [
        "valuation.pe",
        "valuation.pb",
        "quality.roe",
        "quality.roa",
        "banking.gross_npa",
        "banking.net_npa",
        "banking.capital_adequacy",
        "banking.loan_growth",
        "banking.deposit_growth",
    ],
    "nbfc": [
        "valuation.pe",
        "valuation.pb",
        "quality.roe",
        "quality.roa",
        "banking.gross_npa",
        "banking.net_npa",
        "banking.capital_adequacy",
        "quality.debt_to_equity",
    ],
    "infrastructure": [
        "valuation.pe",
        "valuation.ev_ebitda",
        "quality.roce",
        "quality.ocf_to_pat",
        "quality.net_debt_to_ebitda",
        "quality.interest_coverage",
        "operating.order_book_to_revenue",
        "operating.working_capital_days",
    ],
    "power": [
        "valuation.pe",
        "quality.roce",
        "quality.ocf_to_pat",
        "quality.net_debt_to_ebitda",
        "quality.interest_coverage",
    ],
    "pharma": [
        "valuation.pe",
        "quality.roce",
        "quality.revenue_cagr_3y",
        "quality.profit_cagr_3y",
        "quality.ocf_to_pat",
        "quality.fcf_positive_years_5",
        "qualitative.regulatory_or_pipeline_quality",
    ],
    "cyclical": [
        "valuation.pb",
        "valuation.ev_ebitda",
        "quality.roce",
        "quality.net_debt_to_ebitda",
        "quality.interest_coverage",
        "valuation.dividend_yield",
        "qualitative.cyclicality",
    ],
    "auto": [
        "valuation.pe",
        "quality.roce",
        "quality.profit_cagr_3y",
        "quality.ocf_to_pat",
        "quality.net_debt_to_ebitda",
        "operating.market_share_trend",
    ],
    "real_estate": [
        "valuation.pb",
        "quality.net_debt_to_ebitda",
        "operating.presales_growth",
        "operating.collections_to_sales",
        "operating.nav_discount",
        "qualitative.governance",
    ],
    "hospitality": [
        "valuation.ev_ebitda",
        "quality.roce",
        "quality.net_debt_to_ebitda",
        "quality.ocf_to_pat",
        "qualitative.governance",
    ],
    "generic": [
        "valuation.pe",
        "quality.roe",
        "quality.roce",
        "quality.profit_cagr_3y",
        "quality.ocf_to_pat",
        "quality.net_debt_to_ebitda",
    ],
}


def clamp(value: float, lower: float = 0.0, upper: float = 100.0) -> float:
    return max(lower, min(upper, value))


def number(value: Any) -> float | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(result) or math.isinf(result):
        return None
    return result


def get(data: dict[str, Any], path: str) -> Any:
    current: Any = data
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            return None
        current = current[part]
    return current


def linear_score(value: float | None, points: list[tuple[float, float]]) -> float | None:
    """Interpolate score across ordered x/score points."""
    if value is None:
        return None
    ordered = sorted(points, key=lambda item: item[0])
    if value <= ordered[0][0]:
        return clamp(ordered[0][1])
    if value >= ordered[-1][0]:
        return clamp(ordered[-1][1])
    for (x0, y0), (x1, y1) in zip(ordered, ordered[1:]):
        if x0 <= value <= x1:
            ratio = (value - x0) / (x1 - x0)
            return clamp(y0 + ratio * (y1 - y0))
    return None


def average(values: Iterable[float | None]) -> float | None:
    available = [float(v) for v in values if v is not None]
    if not available:
        return None
    return sum(available) / len(available)


def weighted_average(items: Iterable[tuple[float | None, float]]) -> float | None:
    valid = [(float(value), float(weight)) for value, weight in items if value is not None and weight > 0]
    if not valid:
        return None
    total_weight = sum(weight for _, weight in valid)
    return sum(value * weight for value, weight in valid) / total_weight


def round_score(value: float | None) -> float:
    return round(clamp(value if value is not None else 50.0), 1)


def add_metric_reason(
    positive: list[str],
    cautions: list[str],
    value: float | None,
    good_threshold: float,
    bad_threshold: float,
    good_text: str,
    bad_text: str,
    higher_is_better: bool = True,
) -> None:
    if value is None:
        return
    if higher_is_better:
        if value >= good_threshold:
            positive.append(good_text.format(value=value))
        elif value <= bad_threshold:
            cautions.append(bad_text.format(value=value))
    else:
        if value <= good_threshold:
            positive.append(good_text.format(value=value))
        elif value >= bad_threshold:
            cautions.append(bad_text.format(value=value))


def valuation_scores(data: dict[str, Any], sector: str) -> tuple[float, list[str], list[str]]:
    v = data.get("valuation", {}) or {}
    q = data.get("quality", {}) or {}
    b = data.get("banking", {}) or {}
    market_cap_band = str(get(data, "company.market_cap_band") or "").lower()
    pe = number(v.get("pe"))
    pb = number(v.get("pb"))
    ev = number(v.get("ev_ebitda"))
    dividend = number(v.get("dividend_yield"))
    fcf_yield = number(v.get("fcf_yield"))
    positive: list[str] = []
    cautions: list[str] = []

    if pe is not None and pe <= 0:
        pe = None
        cautions.append("P/E is not meaningful because earnings are non-positive or the value is invalid.")

    if sector == "bank":
        pe_score = linear_score(pe, [(5, 100), (8, 100), (10, 92), (13, 75), (18, 50), (25, 25), (40, 8)])
        pb_score = linear_score(pb, [(0.4, 98), (0.8, 92), (1.2, 82), (1.8, 65), (2.8, 42), (4.5, 18)])
        roa = number(q.get("roa"))
        roe = number(q.get("roe"))
        net_npa = number(b.get("net_npa"))
        quality_exception = (
            roa is not None
            and roe is not None
            and net_npa is not None
            and roa >= 1.3
            and roe >= 15
            and net_npa <= 1.0
        )
        if quality_exception and pe_score is not None:
            pe_score = min(100.0, pe_score + 12.0)
            positive.append("Quality-bank exception applies: strong returns and controlled net NPA justify some valuation flexibility.")
        if pe is not None:
            if market_cap_band in {"small", "mid", "regional"} and pe <= 10:
                positive.append(f"P/E of {pe:.1f}x matches Shri's preference for smaller banks below roughly 10x earnings.")
            elif pe > 18 and not quality_exception:
                cautions.append(f"P/E of {pe:.1f}x is above Shri's normal bank comfort zone without a proven quality exception.")
        return round_score(weighted_average([(pe_score, 0.62), (pb_score, 0.38)])), positive, cautions

    if sector == "nbfc":
        pe_score = linear_score(pe, [(7, 98), (12, 90), (18, 72), (25, 52), (35, 28), (50, 10)])
        pb_score = linear_score(pb, [(0.7, 95), (1.5, 84), (2.5, 65), (4, 42), (6, 18)])
        return round_score(weighted_average([(pe_score, 0.65), (pb_score, 0.35)])), positive, cautions

    if sector == "pharma":
        pe_score = linear_score(pe, [(10, 96), (18, 90), (25, 73), (35, 52), (50, 28), (70, 10)])
        ev_score = linear_score(ev, [(6, 96), (12, 82), (18, 62), (28, 35), (40, 15)])
        return round_score(weighted_average([(pe_score, 0.7), (ev_score, 0.3)])), positive, cautions

    if sector in {"infrastructure", "power", "hospitality"}:
        pe_score = linear_score(pe, [(5, 95), (10, 88), (16, 72), (24, 50), (35, 28), (50, 10)])
        ev_score = linear_score(ev, [(3, 98), (7, 86), (11, 68), (16, 45), (24, 20)])
        return round_score(weighted_average([(pe_score, 0.45), (ev_score, 0.55)])), positive, cautions

    if sector == "cyclical":
        pe_score = linear_score(pe, [(3, 92), (6, 85), (10, 65), (16, 42), (25, 20)])
        pb_score = linear_score(pb, [(0.4, 96), (0.9, 88), (1.4, 70), (2.2, 45), (3.5, 18)])
        ev_score = linear_score(ev, [(2, 98), (5, 88), (8, 68), (12, 42), (18, 18)])
        cyc = number(get(data, "qualitative.cyclicality"))
        score = weighted_average([(pe_score, 0.25), (pb_score, 0.35), (ev_score, 0.4)])
        if score is None:
            score = 50.0
        if cyc is not None and cyc >= 70 and pe is not None and pe <= 8:
            score = min(score, 68.0)
            cautions.append("Trailing low P/E is capped because a highly cyclical company may be near peak earnings.")
        return round_score(score), positive, cautions

    if sector in {"real_estate"}:
        pb_score = linear_score(pb, [(0.3, 98), (0.8, 88), (1.4, 70), (2.5, 45), (4, 18)])
        nav_discount = number(get(data, "operating.nav_discount"))
        nav_score = linear_score(nav_discount, [(-20, 20), (0, 45), (20, 70), (40, 88), (60, 98)])
        return round_score(weighted_average([(pb_score, 0.45), (nav_score, 0.55)])), positive, cautions

    pe_score = linear_score(pe, [(5, 96), (10, 90), (18, 75), (25, 58), (35, 38), (50, 18)])
    ev_score = linear_score(ev, [(3, 96), (7, 86), (12, 68), (18, 45), (28, 20)])
    yield_score = linear_score(dividend, [(0, 30), (1, 50), (3, 75), (5, 90), (8, 98)])
    fcf_score = linear_score(fcf_yield, [(-2, 10), (0, 35), (3, 65), (6, 85), (10, 98)])
    return round_score(weighted_average([(pe_score, 0.55), (ev_score, 0.25), (yield_score, 0.1), (fcf_score, 0.1)])), positive, cautions


def quality_scores(data: dict[str, Any], sector: str) -> tuple[float, float, float, list[str], list[str]]:
    q = data.get("quality", {}) or {}
    b = data.get("banking", {}) or {}
    o = data.get("operating", {}) or {}
    qualitative = data.get("qualitative", {}) or {}
    positive: list[str] = []
    cautions: list[str] = []

    roe = number(q.get("roe"))
    roa = number(q.get("roa"))
    roce = number(q.get("roce"))
    revenue_growth = number(q.get("revenue_cagr_3y"))
    profit_growth = number(q.get("profit_cagr_3y"))
    ocf_pat = number(q.get("ocf_to_pat"))
    fcf_years = number(q.get("fcf_positive_years_5"))
    interest = number(q.get("interest_coverage"))
    debt_equity = number(q.get("debt_to_equity"))
    net_debt = number(q.get("net_debt_to_ebitda"))
    governance = number(qualitative.get("governance"))
    management = number(qualitative.get("management_execution"))
    capital_allocation = number(qualitative.get("capital_allocation"))

    if sector in {"bank", "nbfc"}:
        roa_score = linear_score(roa, [(0.3, 12), (0.7, 38), (1.0, 58), (1.3, 76), (1.8, 94), (2.5, 100)])
        roe_score = linear_score(roe, [(5, 15), (9, 38), (12, 58), (15, 78), (19, 94), (24, 100)])
        gnpa = number(b.get("gross_npa"))
        nnpa = number(b.get("net_npa"))
        credit_cost = number(b.get("credit_cost"))
        pcr = number(b.get("provision_coverage"))
        car = number(b.get("capital_adequacy"))
        npa_score = weighted_average([
            (linear_score(gnpa, [(0.5, 100), (1.5, 92), (3, 70), (5, 42), (8, 15)]), 0.45),
            (linear_score(nnpa, [(0.1, 100), (0.6, 92), (1.5, 68), (3, 38), (5, 12)]), 0.45),
            (linear_score(credit_cost, [(0.1, 100), (0.5, 88), (1.2, 60), (2.5, 25), (4, 8)]), 0.1),
        ])
        capital_score = weighted_average([
            (linear_score(car, [(9, 15), (12, 50), (15, 75), (18, 92), (24, 100)]), 0.75),
            (linear_score(pcr, [(40, 20), (55, 45), (70, 72), (85, 92), (100, 100)]), 0.25),
        ])
        loan_growth = number(b.get("loan_growth"))
        deposit_growth = number(b.get("deposit_growth"))
        nim = number(b.get("nim"))
        growth_score = weighted_average([
            (linear_score(loan_growth, [(-5, 5), (3, 30), (8, 55), (14, 82), (22, 95), (35, 65)]), 0.35),
            (linear_score(deposit_growth, [(-5, 5), (3, 30), (8, 58), (13, 82), (20, 95), (30, 78)]), 0.35),
            (linear_score(nim, [(1.5, 18), (2.2, 45), (3.0, 72), (4.0, 92), (5.5, 100)]), 0.15),
            (linear_score(profit_growth, [(-15, 5), (0, 35), (8, 58), (15, 78), (25, 92), (40, 100)]), 0.15),
        ])
        if loan_growth is not None and deposit_growth is not None and loan_growth - deposit_growth > 6:
            growth_score = max(0.0, (growth_score if growth_score is not None else 50.0) - 12.0)
            cautions.append("Loan growth materially exceeds deposit growth, which may pressure funding or margins.")
        quality_score = weighted_average([(roa_score, 0.28), (roe_score, 0.22), (npa_score, 0.32), (management, 0.1), (governance, 0.08)])
        balance_score = weighted_average([(capital_score, 0.55), (npa_score, 0.25), (governance, 0.2)])
        trend_score = growth_score

        add_metric_reason(positive, cautions, roa, 1.3, 0.8, "ROA of {value:.2f}% supports a quality-bank exception.", "ROA of {value:.2f}% is too weak to make a low valuation compelling.")
        add_metric_reason(positive, cautions, nnpa, 1.0, 2.5, "Net NPA of {value:.2f}% is controlled.", "Net NPA of {value:.2f}% raises value-trap risk.", higher_is_better=False)
        return round_score(quality_score), round_score(balance_score), round_score(trend_score), positive, cautions

    roce_score = linear_score(roce, [(2, 10), (7, 35), (12, 58), (18, 80), (25, 94), (35, 100)])
    roe_score = linear_score(roe, [(3, 12), (8, 38), (12, 60), (18, 82), (25, 96), (35, 100)])
    ocf_score = linear_score(ocf_pat, [(-0.5, 5), (0, 18), (0.6, 55), (1.0, 80), (1.4, 95), (2.0, 100)])
    fcf_score = linear_score(fcf_years, [(0, 5), (1, 25), (2, 45), (3, 68), (4, 86), (5, 100)])
    interest_score = linear_score(interest, [(0.5, 5), (1.2, 18), (2, 45), (4, 72), (7, 90), (12, 100)])
    debt_equity_score = linear_score(debt_equity, [(0, 100), (0.4, 90), (1, 68), (2, 42), (4, 15), (8, 5)])
    net_debt_score = linear_score(net_debt, [(-1, 100), (0, 96), (1, 82), (2.5, 62), (4, 38), (6, 15), (9, 5)])
    revenue_score = linear_score(revenue_growth, [(-10, 5), (0, 35), (8, 58), (15, 78), (25, 94), (40, 100)])
    profit_score = linear_score(profit_growth, [(-20, 5), (0, 35), (8, 58), (15, 76), (25, 92), (40, 100)])

    quality_score = weighted_average([
        (roce_score, 0.28),
        (roe_score, 0.12),
        (ocf_score, 0.2),
        (fcf_score, 0.12),
        (management, 0.1),
        (capital_allocation, 0.08),
        (governance, 0.1),
    ])
    balance_score = weighted_average([
        (interest_score, 0.35),
        (net_debt_score, 0.35),
        (debt_equity_score, 0.15),
        (governance, 0.15),
    ])
    trend_score = weighted_average([(revenue_score, 0.42), (profit_score, 0.48), (management, 0.1)])

    if sector == "infrastructure":
        order_book = number(o.get("order_book_to_revenue"))
        wc_days = number(o.get("working_capital_days"))
        order_score = linear_score(order_book, [(0, 10), (0.8, 45), (1.5, 70), (2.5, 90), (4, 100), (7, 82)])
        wc_score = linear_score(wc_days, [(20, 100), (60, 88), (100, 68), (160, 40), (240, 15), (360, 5)])
        trend_score = weighted_average([(trend_score, 0.55), (order_score, 0.25), (wc_score, 0.2)])
        if order_book is not None and order_book >= 2 and (ocf_pat is None or ocf_pat < 0.7):
            cautions.append("A strong order book is not yet supported by convincing operating cash conversion.")

    if sector == "pharma":
        regulatory = number(qualitative.get("regulatory_or_pipeline_quality"))
        quality_score = weighted_average([(quality_score, 0.8), (regulatory, 0.2)])
        if regulatory is not None and regulatory < 45:
            cautions.append("Regulatory or pipeline quality is weak enough to cap enthusiasm despite valuation.")

    if sector == "auto":
        market_share = number(o.get("market_share_trend"))
        market_score = linear_score(market_share, [(-5, 5), (-1, 30), (0, 50), (1, 68), (3, 88), (6, 100)])
        trend_score = weighted_average([(trend_score, 0.72), (market_score, 0.28)])

    if sector == "real_estate":
        presales = number(o.get("presales_growth"))
        collections = number(o.get("collections_to_sales"))
        presales_score = linear_score(presales, [(-20, 5), (0, 40), (10, 62), (25, 85), (50, 100)])
        collections_score = linear_score(collections, [(40, 10), (65, 45), (85, 75), (100, 92), (120, 100)])
        trend_score = weighted_average([(trend_score, 0.45), (presales_score, 0.3), (collections_score, 0.25)])

    add_metric_reason(positive, cautions, roce, 18, 8, "ROCE of {value:.1f}% indicates productive capital use.", "ROCE of {value:.1f}% is weak for the business risk.")
    add_metric_reason(positive, cautions, ocf_pat, 1.0, 0.4, "Operating cash flow broadly supports reported profit at {value:.2f}x PAT.", "Operating cash flow at {value:.2f}x PAT does not adequately support reported earnings.")
    add_metric_reason(positive, cautions, net_debt, 1.5, 4.0, "Net debt/EBITDA of {value:.1f}x is manageable.", "Net debt/EBITDA of {value:.1f}x leaves little room for execution errors.", higher_is_better=False)
    return round_score(quality_score), round_score(balance_score), round_score(trend_score), positive, cautions


def fit_score(data: dict[str, Any], valuation_score: float, trend_score: float) -> tuple[float, list[str], list[str]]:
    q = data.get("qualitative", {}) or {}
    tangible = number(q.get("tangible_assets"))
    understandable = number(q.get("understandability"))
    tailwind = number(q.get("india_tailwind"))
    catalyst = number(q.get("catalyst"))
    capital_allocation = number(q.get("capital_allocation"))
    dividend = number(get(data, "valuation.dividend_yield"))
    dividend_score = linear_score(dividend, [(0, 30), (1, 48), (3, 72), (5, 88), (8, 100)])

    score = weighted_average([
        (valuation_score, 0.24),
        (catalyst, 0.20),
        (tangible, 0.14),
        (tailwind, 0.13),
        (trend_score, 0.11),
        (understandable, 0.09),
        (capital_allocation, 0.05),
        (dividend_score, 0.04),
    ])
    positive: list[str] = []
    cautions: list[str] = []
    if catalyst is not None and catalyst >= 70:
        positive.append("A visible rerating or operating catalyst matches Shri's preference for change plus value.")
    elif catalyst is not None and catalyst < 40:
        cautions.append("The thesis appears cheap or thematic without a sufficiently visible catalyst.")
    if tangible is not None and tangible >= 70:
        positive.append("The business has tangible assets or an understandable economic engine.")
    if tailwind is not None and tailwind >= 70:
        positive.append("The company participates in an India-specific structural tailwind.")
    return round_score(score), positive, cautions


def portfolio_score(data: dict[str, Any]) -> tuple[float, list[str]]:
    p = data.get("portfolio", {}) or {}
    current_weight = number(p.get("current_weight"))
    sector_weight = number(p.get("sector_weight"))
    overlap = number(p.get("overlap_score"))
    score = 78.0
    cautions: list[str] = []
    if current_weight is not None:
        if current_weight >= 8:
            score -= 35
            cautions.append(f"Current portfolio weight of {current_weight:.1f}% is already concentrated.")
        elif current_weight >= 5:
            score -= 22
            cautions.append(f"Current portfolio weight of {current_weight:.1f}% leaves limited room before concentration rises.")
        elif current_weight >= 3:
            score -= 10
    if sector_weight is not None:
        if sector_weight >= 35:
            score -= 30
            cautions.append(f"Sector exposure of {sector_weight:.1f}% creates substantial common-factor risk.")
        elif sector_weight >= 25:
            score -= 18
            cautions.append(f"Sector exposure of {sector_weight:.1f}% is already elevated.")
        elif sector_weight >= 18:
            score -= 7
    if overlap is not None:
        if overlap >= 80:
            score -= 20
            cautions.append("The stock closely duplicates drivers already present in the portfolio.")
        elif overlap >= 60:
            score -= 10
    return round_score(score), cautions


def confidence_score(data: dict[str, Any], sector: str) -> tuple[float, list[str]]:
    required = SECTOR_REQUIRED.get(sector, SECTOR_REQUIRED["generic"])
    present = sum(1 for path in required if number(get(data, path)) is not None)
    completeness = 100.0 * present / max(1, len(required))
    declared = number(get(data, "qualitative.data_confidence"))
    score = weighted_average([(completeness, 0.72), (declared, 0.28)]) or completeness
    missing = [path for path in required if number(get(data, path)) is None]
    return round_score(score), missing


def apply_red_flags(data: dict[str, Any]) -> tuple[float, float | None, list[str]]:
    penalty = 0.0
    hard_cap: float | None = None
    cautions: list[str] = []
    severe_codes = {
        "fraud",
        "insolvency",
        "auditor_resignation",
        "qualified_audit",
        "governance_severe",
        "regulatory_threat",
    }
    for item in data.get("red_flags", []) or []:
        if isinstance(item, str):
            code = item.lower().strip().replace(" ", "_")
            severity = "medium"
            note = item
        elif isinstance(item, dict):
            code = str(item.get("code", "unknown")).lower().strip().replace(" ", "_")
            severity = str(item.get("severity", "medium")).lower()
            note = str(item.get("note") or code.replace("_", " "))
        else:
            continue
        penalty += {"low": 3.0, "medium": 8.0, "high": 16.0, "severe": 24.0}.get(severity, 8.0)
        cautions.append(f"Red flag ({severity}): {note}.")
        if code in severe_codes or severity == "severe":
            hard_cap = min(hard_cap or 100.0, 45.0)
    return penalty, hard_cap, cautions


def classify(happiness: float, fit: float, fundamental: float, confidence: float) -> tuple[str, str, str]:
    if confidence < 40:
        confidence_label = "Low confidence — needs data"
    elif confidence < 70:
        confidence_label = "Medium confidence"
    else:
        confidence_label = "Higher confidence"

    if fit >= 70 and fundamental >= 70:
        quadrant = "Shri-aligned quality candidate"
    elif fit >= 70 and fundamental < 55:
        quadrant = "Shri-shaped value-trap risk"
    elif fit < 60 and fundamental >= 75:
        quadrant = "Strong business, not naturally Shri-priced"
    else:
        quadrant = "Needs proof"

    if confidence < 40:
        label = "Needs data before judgment"
    elif happiness >= 85:
        label = "Very Shri — serious research candidate"
    elif happiness >= 72:
        label = "Strong Shri match — verify valuation and risk"
    elif happiness >= 58:
        label = "Interesting — more proof required"
    elif happiness >= 42:
        label = "Tempting, but not enough"
    else:
        label = "Low match or red-flagged"
    return label, quadrant, confidence_label


def kill_conditions(sector: str) -> list[str]:
    common = [
        "Material governance, audit, or related-party evidence deteriorates.",
        "The catalyst is disproved or is achieved without an improvement in per-share economics.",
        "The thesis requires permanently rising valuation multiples rather than business progress.",
    ]
    sector_specific = {
        "bank": [
            "ROA remains structurally weak while the stock only appears cheap on P/E or P/B.",
            "Deposit growth persistently trails loan growth or asset-quality slippages accelerate.",
        ],
        "nbfc": [
            "Stage 2/3 assets, credit cost, funding cost, or ALM risk deteriorate faster than AUM grows.",
        ],
        "infrastructure": [
            "Order-book growth fails to convert into operating cash flow or leverage rises without realised monetisation.",
        ],
        "power": [
            "Capex returns fall below the cost of capital or debt grows faster than contracted cash flows.",
        ],
        "pharma": [
            "A regulatory or product-quality issue expands beyond the base case or the launch pipeline fails.",
        ],
        "cyclical": [
            "Normalized earnings and asset value no longer support the price after the cycle turns.",
        ],
        "auto": [
            "Market share, margins, or automotive free cash flow deteriorate despite the product cycle.",
        ],
        "real_estate": [
            "Collections, approvals, title, delivery, or leverage evidence breaks the NAV thesis.",
        ],
        "hospitality": [
            "Occupancy or pricing normalizes while leverage and capex remain elevated.",
        ],
        "generic": [
            "Cash conversion or returns on incremental capital remain below the required level.",
        ],
    }
    return common + sector_specific.get(sector, sector_specific["generic"])


def analyze(data: dict[str, Any]) -> dict[str, Any]:
    company = data.get("company", {}) or {}
    sector = str(company.get("sector") or "generic").lower().strip().replace(" ", "_")
    if sector not in SECTOR_REQUIRED:
        sector = "generic"

    valuation, valuation_positive, valuation_cautions = valuation_scores(data, sector)
    quality, balance, trend, quality_positive, quality_cautions = quality_scores(data, sector)
    fit, fit_positive, fit_cautions = fit_score(data, valuation, trend)
    portfolio, portfolio_cautions = portfolio_score(data)
    confidence, missing = confidence_score(data, sector)
    governance = number(get(data, "qualitative.governance"))

    fundamental = round_score(weighted_average([
        (quality, 0.42),
        (balance, 0.25),
        (trend, 0.18),
        (governance, 0.15),
    ]))

    happiness = weighted_average([
        (fit, 0.40),
        (fundamental, 0.34),
        (valuation, 0.16),
        (portfolio, 0.10),
    ]) or 50.0

    red_penalty, hard_cap, red_cautions = apply_red_flags(data)
    happiness = clamp(happiness - red_penalty)
    if governance is not None and governance < 35:
        hard_cap = min(hard_cap or 100.0, 49.0)
        red_cautions.append("Low governance score caps the composite regardless of valuation.")
    if hard_cap is not None:
        happiness = min(happiness, hard_cap)
    happiness = round_score(happiness)

    label, quadrant, confidence_label = classify(happiness, fit, fundamental, confidence)

    positive = valuation_positive + quality_positive + fit_positive
    cautions = valuation_cautions + quality_cautions + fit_cautions + portfolio_cautions + red_cautions
    # Keep output concise and deterministic.
    positive = list(dict.fromkeys(positive))[:7]
    cautions = list(dict.fromkeys(cautions))[:9]

    neighbor_names = SECTOR_NEIGHBORS.get(sector, [])
    overlap = number(get(data, "portfolio.overlap_score"))
    relationship_note = (
        "High overlap with existing portfolio drivers."
        if overlap is not None and overlap >= 70
        else "Moderate overlap with existing portfolio drivers."
        if overlap is not None and overlap >= 45
        else "Potential diversifier relative to existing holdings."
        if overlap is not None
        else "Portfolio overlap requires user-supplied weights or factor tags."
    )

    score_components = [
        {"name": "Shri fit", "score": fit, "composite_weight": 0.40},
        {"name": "Fundamental quality", "score": fundamental, "composite_weight": 0.34},
        {"name": "Valuation comfort", "score": valuation, "composite_weight": 0.16},
        {"name": "Portfolio fit", "score": portfolio, "composite_weight": 0.10},
        {"name": "Balance sheet", "score": balance, "composite_weight": 0.0},
        {"name": "Trend", "score": trend, "composite_weight": 0.0},
        {"name": "Evidence confidence", "score": confidence, "composite_weight": 0.0},
    ]

    return {
        "schema_version": SCHEMA_VERSION,
        "company": company,
        "as_of": data.get("dates", {}) or {},
        "scores": {
            "happiness_score": happiness,
            "shri_fit_score": fit,
            "fundamental_quality_score": fundamental,
            "valuation_score": valuation,
            "balance_sheet_score": balance,
            "trend_score": trend,
            "portfolio_fit_score": portfolio,
            "confidence_score": confidence,
        },
        "classification": {
            "label": label,
            "quadrant": quadrant,
            "confidence_label": confidence_label,
        },
        "reasons": {
            "positive": positive,
            "cautions": cautions,
            "missing": missing,
            "kill_conditions": kill_conditions(sector),
        },
        "score_components": score_components,
        "portfolio_relationship": {
            "closest_holdings": neighbor_names,
            "note": relationship_note,
        },
        "sources": data.get("sources", []) or [],
        "analyst_notes": data.get("analyst_notes", []) or [],
        "disclaimer": DISCLAIMER,
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Score a stock using Shri's Stock Brain model.")
    parser.add_argument("--input", required=True, help="Path to normalized company JSON")
    parser.add_argument("--output", required=True, help="Path to write analysis JSON")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    input_path = Path(args.input)
    output_path = Path(args.output)
    try:
        data = json.loads(input_path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        print(f"Input file not found: {input_path}", file=sys.stderr)
        return 2
    except json.JSONDecodeError as exc:
        print(f"Invalid JSON in {input_path}: {exc}", file=sys.stderr)
        return 2
    if not isinstance(data, dict):
        print("Input JSON must be an object.", file=sys.stderr)
        return 2
    result = analyze(data)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Wrote {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
