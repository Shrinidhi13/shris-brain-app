---
name: shris-stock-brain
description: analyze indian listed stocks and uploaded company data through shri's personal value, catalyst, quality, and tangible-asset investment philosophy. use when a user asks for a shri happiness score, shri's choice, philosophy fit, sector-specific fundamental review, value-trap check, portfolio similarity map, or a structured json analysis for manual import into the companion shri's brain web app.
---

# Shri's Stock Brain

## Purpose

Evaluate a listed stock as a research candidate through two separate lenses:

1. **Shri fit**: how closely the stock matches the learned philosophy.
2. **Fundamental quality**: whether the business and evidence are actually strong.

Never let philosophy fit substitute for business quality. A cheap, cyclical, leveraged, or low-governance stock can match Shri's instincts and still be a poor research candidate.

## Required references

Read the following only as needed:

- `references/shri-profile.md` for calibration holdings, exclusions, and preferences.
- `references/sector-rules.md` for sector-specific metrics and exception logic.
- `references/source-policy.md` for current-data sourcing and freshness rules.
- `references/app-handoff.md` when producing JSON for the companion web app.

## Workflow

1. **Resolve the security.** Confirm company name, ticker, exchange, security type, and whether it is a stock, ETF, demerged share, rights entitlement, or other corporate-action residue. Do not infer the company from an ambiguous ticker.
2. **Choose the data path.**
   - For a ticker request, search the web for current primary evidence.
   - For an uploaded filing, export, spreadsheet, or JSON file, use it as the first source and supplement only material gaps.
   - If current fundamentals cannot be obtained reliably, request the exact missing fields or provide the bundled input template. Do not fabricate values.
3. **Gather evidence.** Prefer exchange filings, company annual or quarterly reports, investor presentations, and official regulatory disclosures. Add a market-data provider only for price, market cap, and trading fields. Record an as-of date for every important value.
4. **Normalize the evidence.** Map available values to the schema in `references/app-handoff.md`. Keep missing fields null. Do not turn missing values into zeroes.
5. **Run deterministic scoring.** Save the normalized input as JSON and run:

   ```bash
   python scripts/score_stock.py --input company.json --output analysis.json
   ```

6. **Apply analyst judgment.** Challenge the numeric result using `references/sector-rules.md`. Check accounting quality, cycle position, governance, leverage, cash conversion, dilution, concentration, and whether the apparent catalyst is already priced in.
7. **Apply the bias guard.** Explicitly test for:
   - low-P/E value traps;
   - peak-cycle earnings masquerading as cheap valuation;
   - weak banks that look cheap only because ROA or asset quality is poor;
   - infrastructure order books without operating cash flow;
   - debt-funded growth;
   - policy-tailwind stories without company-level economics;
   - anchoring to a purchase price;
   - outcome bias from prior winners.
8. **Produce the result.** Return the decision summary, score decomposition, reasons for and against, missing data, kill conditions, portfolio overlap, and sources. When requested, also return an app-compatible JSON file.

## Data and sourcing rules

- Search current information whenever the answer depends on current price, valuation, filings, management guidance, regulation, corporate actions, or recent events.
- Cite factual claims and state the exact as-of date.
- Treat free market-data APIs as convenience feeds, not the fundamental source of truth.
- Do not scrape a website that prohibits automated use or present an unofficial endpoint as reliable.
- Distinguish real-time, delayed, end-of-day, and filing-date information.
- Prefer the latest annual report plus the latest reported quarter. Do not compare a current price with stale earnings without saying so.
- Never use mutual-fund look-through holdings as if Shri personally selected those stocks.

## Scoring interpretation

Use the script output but preserve these distinctions:

- `happiness_score`: transparent composite, not a buy recommendation.
- `shri_fit_score`: philosophy match.
- `fundamental_quality_score`: business and financial quality.
- `valuation_score`: sector-aware valuation comfort.
- `portfolio_fit_score`: diversification and concentration fit.
- `confidence_score`: evidence completeness and freshness.

A high score with low confidence must be labelled **needs data**. A high Shri fit with low fundamental quality must be labelled **Shri-shaped value-trap risk**.

## Output structure

Use this order for a normal response:

1. **Shri Happiness Meter**: score, label, confidence, and one-sentence verdict.
2. **Two-axis decision**: Shri fit versus fundamental quality, including the quadrant.
3. **Why Shri may like it**: three to five evidence-backed reasons.
4. **What may fool Shri**: the strongest contrary evidence and bias risks.
5. **Sector test**: the sector-specific metrics that passed, failed, or are missing.
6. **Portfolio relationship**: closest current holdings, factor overlap, and whether it adds diversification.
7. **What would change the result**: positive triggers, negative kill conditions, and required next evidence.
8. **Sources and freshness**: primary sources first, with dates.
9. **Disclaimer**: educational research tool; not personalised investment advice or a recommendation to transact.

When the user requests app import, include or attach the exact JSON defined in `references/app-handoff.md` and explain that the handoff is a file import rather than a live Skill call.

## Boundaries

- Do not issue definitive buy, sell, target-price, or guaranteed-return instructions.
- Do not imply that past performance proves the philosophy.
- Do not describe user-reported returns as independently verified.
- Do not hide missing data behind a precise score.
- Do not reward a low P/E without sector-normalized earnings and balance-sheet checks.
- Do not expose private broker statements or personal identifiers in a public artifact.
