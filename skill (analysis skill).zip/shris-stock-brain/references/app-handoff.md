# Companion app handoff

## Runtime relationship

Treat the Skill and web app as companion components connected by a **manual JSON file handoff**, not by a live runtime call. Produce the JSON in ChatGPT, save or attach it, and let the user import it in the web app. Do not claim that the static web app can invoke the installed Skill directly.

## Input JSON

The scoring script accepts a JSON object with this structure. Fields may be null.

```json
{
  "company": {
    "name": "Example Bank Limited",
    "symbol": "EXAMPLE.BSE",
    "exchange": "BSE",
    "security_type": "equity",
    "sector": "bank",
    "subsector": "regional bank",
    "market_cap_band": "small",
    "currency": "INR"
  },
  "dates": {
    "price_as_of": "2026-07-10",
    "fundamentals_as_of": "2026-03-31",
    "freshness": "latest_annual_report"
  },
  "valuation": {
    "price": 100.0,
    "market_cap_cr": 5000.0,
    "pe": 8.5,
    "pb": 1.1,
    "ev_ebitda": null,
    "dividend_yield": 1.2,
    "fcf_yield": null
  },
  "quality": {
    "roe": 15.0,
    "roa": 1.2,
    "roce": null,
    "revenue_cagr_3y": 12.0,
    "profit_cagr_3y": 16.0,
    "ocf_to_pat": null,
    "fcf_positive_years_5": null,
    "interest_coverage": null,
    "debt_to_equity": null,
    "net_debt_to_ebitda": null
  },
  "banking": {
    "gross_npa": 2.1,
    "net_npa": 0.7,
    "credit_cost": 0.5,
    "provision_coverage": 75.0,
    "capital_adequacy": 16.0,
    "casa": 32.0,
    "nim": 3.2,
    "loan_growth": 14.0,
    "deposit_growth": 13.0
  },
  "operating": {
    "operating_margin": null,
    "net_margin": null,
    "order_book_to_revenue": null,
    "working_capital_days": null,
    "market_share_trend": null,
    "presales_growth": null,
    "collections_to_sales": null,
    "nav_discount": null
  },
  "qualitative": {
    "governance": 75,
    "management_execution": 70,
    "capital_allocation": 65,
    "tangible_assets": 80,
    "understandability": 85,
    "india_tailwind": 75,
    "catalyst": 70,
    "regulatory_or_pipeline_quality": null,
    "cyclicality": 35,
    "data_confidence": 75
  },
  "portfolio": {
    "current_weight": 0.0,
    "sector_weight": 20.0,
    "overlap_score": 55.0
  },
  "red_flags": [],
  "sources": [
    {
      "title": "Annual report",
      "url": "https://example.com/report",
      "date": "2026-05-30",
      "type": "company_filing"
    }
  ],
  "analyst_notes": []
}
```

Supported sector values:

- `bank`
- `nbfc`
- `infrastructure`
- `power`
- `pharma`
- `cyclical`
- `auto`
- `real_estate`
- `hospitality`
- `generic`

## Script output

The script returns:

```json
{
  "schema_version": "1.0",
  "company": {},
  "as_of": {},
  "scores": {
    "happiness_score": 0,
    "shri_fit_score": 0,
    "fundamental_quality_score": 0,
    "valuation_score": 0,
    "balance_sheet_score": 0,
    "trend_score": 0,
    "portfolio_fit_score": 0,
    "confidence_score": 0
  },
  "classification": {
    "label": "",
    "quadrant": "",
    "confidence_label": ""
  },
  "reasons": {
    "positive": [],
    "cautions": [],
    "missing": [],
    "kill_conditions": []
  },
  "score_components": [],
  "sources": [],
  "disclaimer": ""
}
```

The web app imports this output directly. Preserve numbers as numbers and missing values as null. Do not place citations inside numeric strings.
