# Shri profile

## Confidence and intended use

This profile is inferred from one current portfolio and selected exclusions. Treat it as a living hypothesis, not a permanent personality diagnosis. Ask for feedback after several analyses and update the weights only when the user explicitly approves a change. Historical return claims are deliberately excluded from calibration and scoring.

## Calibration universe

Use these current or inherited holdings as philosophy evidence:

- Cipla
- The Karnataka Bank
- Tata Power
- Tata Steel
- Advent Hotels International
- Ashoka Buildcon
- Cholamandalam Investment and Finance
- Dr. Reddy's Laboratories
- IRB Infrastructure Developers
- L&T Finance
- ONGC
- State Bank of India
- Tamilnad Mercantile Bank
- Tata Motors Passenger Vehicles
- Valor Estate

Use Mirae Asset NYSE FANG+ ETF only as evidence of a diversification impulse, not as a directly selected operating company.

Use Great Eastern Shipping only as a historical user-selected cyclical example. Do not infer or display a return from it.

### Excluded from calibration

Do not use these names to learn Shri's philosophy because the user explicitly disowns them:

- Eureka Industries and related rights entitlement
- IRCTC
- GNFC
- Franklin Industries

Do not silently reintroduce them through portfolio averages.

### Lower-signal calibration names

- Advent Hotels is partly a corporate-action consequence.
- Valor Estate may represent a special-situation or asset-value thesis.
- Tiny residual positions reveal less conviction than intentionally sized positions.

## Core philosophy hypothesis

Name: **India tangible-growth and rerating barbell**.

Shri appears to seek understandable businesses where one or more of the following can create asymmetric upside:

1. Low or reasonable valuation, especially in smaller banks and asset-heavy businesses.
2. A visible earnings, balance-sheet, asset-quality, product-cycle, or capital-allocation improvement.
3. Tangible assets, licences, concessions, distribution, plants, roads, loan books, brands, or regulated franchises.
4. India-specific structural tailwinds such as formal credit, infrastructure, power demand, healthcare, manufacturing, or vehicle growth.
5. A rerating catalyst rather than valuation alone.
6. Willingness to hold volatile cyclicals or turnarounds when asset backing and the catalyst appear credible.
7. A smaller quality anchor made up of established financial and pharmaceutical franchises.

This resembles Peter Lynch's mixture of stalwarts, fast growers, cyclicals, turnarounds, asset plays, and special situations more than a pure Buffett-style quality-compounder portfolio.

## Default philosophy weights

Use a 0-100 preference scale:

| Dimension | Default weight | Interpretation |
|---|---:|---|
| Valuation comfort | 92 | Strong preference; especially important for smaller banks and cyclicals |
| Catalyst or rerating path | 88 | Cheapness should have a reason to close |
| Tangible assets and understandability | 82 | Prefers visible economic engines |
| India structural tailwind | 78 | Likes domestic credit, capex, power, healthcare, and mobility themes |
| Balance-sheet resilience | 76 | Important, though the portfolio suggests willingness to accept some leverage |
| Earnings or operating improvement | 74 | Seeks change rather than static cheapness |
| Fundamental quality and returns | 72 | Quality matters but is not always the first screen |
| Cash returns or asset backing | 66 | Dividend, NAV, book value, or hard assets can support the thesis |
| Portfolio diversification | 58 | Present but historically secondary to idea conviction |

## Sector preferences and exceptions

### Banks

- Smaller banks with P/E below 10 are naturally attractive to Shri.
- Never reward that threshold alone. Require acceptable ROA, ROE, capital adequacy, deposit franchise, and improving or controlled NPAs.
- Permit a higher P/E for an exceptional bank when ROA, ROE, asset quality, deposit growth, governance, and earnings durability justify it.
- A bank with low P/E and structurally weak ROA is a likely value trap.

### NBFCs

Prefer scalable distribution, underwriting evidence, improving ROA/ROE, controlled Stage 2/3 assets, and manageable funding cost. Penalize unsecured growth that outruns risk controls.

### Infrastructure and EPC

Like order books, concessions, toll assets, monetisation, and policy tailwinds. Demand operating cash flow, working-capital discipline, project-level economics, and leverage control. Order-book growth without cash conversion is not enough.

### Power and utilities

Like long-duration demand growth and integrated platforms. Test debt-funded capex, regulated returns, project execution, counterparty quality, and free-cash-flow timing.

### Pharma

Treat as a quality and defensive anchor. Test regulatory compliance, product concentration, R&D productivity, geography mix, and pipeline execution. Do not assume every correction is an opportunity.

### Cyclicals: steel, shipping, oil, chemicals

Prefer asset backing, a strong balance sheet, shareholder distributions, and cycle-aware entry. Do not use trailing low P/E at peak margins. Judge normalized earnings and replacement or asset value.

### Auto

Like product-cycle and market-share upside. Test free cash flow, capital intensity, debt, margins, product concentration, and transition risk.

### Real estate and hospitality

Like NAV discounts and special situations but require title, approvals, collections, debt, cash conversion, dilution, and governance evidence.

## Bias guard

Always challenge these likely behavioural risks:

- **Low-P/E attraction**: cheap can signal weak economics or peak earnings.
- **Narrative-to-economics jump**: India capex or policy support does not guarantee shareholder returns.
- **Position-size drift**: a good theme can become a bad portfolio through concentration.
- **Anchoring**: purchase price is not an investment thesis.
- **Historical-winner bias**: one successful cyclical does not validate every cyclical.
- **Complexity optionality**: tiny special situations can consume attention without affecting returns.

## Portfolio similarity clusters

Use these clusters in the app or written analysis:

- **Quality anchors**: SBI, Cholamandalam, Cipla, Dr. Reddy's.
- **Financial rerating**: Karnataka Bank, Tamilnad Mercantile Bank, L&T Finance.
- **India capex and infrastructure**: IRB, Ashoka Buildcon, Tata Power.
- **Asset-backed cyclicals**: Tata Steel, ONGC, Great Eastern Shipping (historical pick).
- **Turnaround or product cycle**: Tata Motors Passenger Vehicles.
- **Special situations and asset plays**: Valor Estate, Advent Hotels.
- **Diversifier, low philosophy signal**: Mirae Asset NYSE FANG+ ETF.
