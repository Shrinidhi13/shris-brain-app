# Sector-specific scoring rules

## Universal rules

Use sector-appropriate metrics. Do not compare bank debt-to-equity with an industrial company or judge a cyclical solely on trailing P/E. Keep missing values null and lower confidence rather than treating them as failures.

Apply a governance cap when there is a severe unresolved issue. Apply a data-confidence warning when less than half of the material sector fields are available.

## Banks

Material fields:

- P/E and P/B.
- ROA and ROE.
- Gross and net NPA, slippages, credit cost, and provision coverage.
- Capital adequacy.
- Loan and deposit growth, CASA, cost of deposits, and NIM.
- Concentration, secured versus unsecured mix, and governance.

Shri-specific valuation rule:

- For a small or regional bank, P/E at or below 10 is a strong fit signal.
- Do not produce a positive conclusion unless the quality test also passes.
- Permit P/E above 10 for a high-quality bank when ROA is approximately 1.3% or better, ROE is approximately 15% or better, net NPA is controlled, capital is adequate, and deposit growth supports loan growth.

Value-trap checks:

- ROA persistently below 0.8%.
- Deposit growth materially below loan growth.
- Weak provision coverage or rising slippages.
- Low P/B supported by poor return on equity.
- Governance or related-party concerns.

## NBFCs and diversified lenders

Material fields:

- P/E and P/B relative to sustainable ROA and ROE.
- AUM growth and product mix.
- Stage 2 and Stage 3 assets, credit cost, and collection efficiency.
- Capital adequacy, borrowing cost, ALM, liquidity, and unsecured exposure.
- Incremental versus back-book underwriting.

Penalize growth that outruns funding, collections, or risk infrastructure.

## Infrastructure, roads, and EPC

Material fields:

- EV/EBITDA, normalized P/E, and sum-of-parts or concession value where supportable.
- Order book to revenue and execution history.
- Operating cash flow, free cash flow, working-capital days, receivables, and arbitration claims.
- Net debt/EBITDA, interest coverage, guarantees, and project-level leverage.
- Asset monetisation and cash actually received.

Do not score an order-book announcement as a catalyst unless economics, funding, and execution timing are known.

## Power and utilities

Material fields:

- Regulated, contracted, and merchant earnings mix.
- ROE or ROCE by business.
- Net debt/EBITDA, capex funding, interest coverage, and free-cash-flow timing.
- Counterparty receivables and regulatory assets.
- Capacity additions, project returns, execution, and fuel or input risk.

## Pharma

Material fields:

- P/E or EV/EBITDA relative to normalized growth.
- ROCE, free cash flow, geography and product concentration.
- Regulatory inspection status and remediation.
- R&D productivity, launches, pipeline quality, and litigation.
- Domestic branded franchise versus price-sensitive export exposure.

A regulatory event can cap the score until the issue is resolved even when valuation becomes cheaper.

## Cyclicals: steel, shipping, oil, chemicals

Material fields:

- Mid-cycle EBITDA, replacement value, P/B or NAV, and EV/EBITDA.
- Net debt through the cycle and liquidity.
- Cost-curve position, utilization, freight or commodity exposure.
- Dividend, buyback, or capital-allocation discipline.
- Current margins versus long-run margins.

If margins are near a cycle peak, cap the reward from trailing low P/E. Show a normalized-earnings scenario.

## Auto and mobility

Material fields:

- Market-share and volume trend.
- Segment margins, product mix, launches, and pricing.
- Automotive free cash flow and net debt.
- Capital intensity, warranty, residual-value, and transition risk.
- Geographic and subsidiary exposure.

## Real estate and hospitality

Material fields:

- NAV discount with transparent asset values.
- Pre-sales, collections, occupancy, ADR or RevPAR as relevant.
- Net debt, interest coverage, construction funding, and dilution.
- Land title, approvals, related-party transactions, and governance.
- Cash conversion and delivery record.

## Severe red flags

Examples that may cap the composite score:

- Auditor resignation or qualified opinion without a credible resolution.
- Material undisclosed related-party transactions.
- Promoter pledge above 50% without strong mitigating evidence.
- Repeated equity dilution with weak returns.
- Persistent positive accounting profit but negative operating cash flow.
- Insolvency, covenant, fraud, or regulatory action that threatens the equity thesis.

Do not automatically reject an event-driven stock, but make the cap and uncertainty explicit.
