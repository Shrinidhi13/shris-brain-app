# Source and freshness policy

## Source hierarchy

Use the smallest set that can support the decision:

1. NSE or BSE corporate filings and official security identifiers.
2. Company annual reports, quarterly results, investor presentations, and earnings materials.
3. SEBI or another relevant regulator.
4. A licensed or clearly documented market-data provider for price and trading fields.
5. Reputable financial reporting for context, with the event date distinguished from publication date.
6. User uploads when official current data is inaccessible.

## Free-data posture

- Alpha Vantage documents global daily equity data and gives a BSE symbol example. Its free service is limited and should be treated as a convenience price feed.
- Do not describe Alpha Vantage as guaranteed NSE real-time data.
- NSE describes its real-time and delayed feed products as paid products. Do not imply that a production public app can redistribute NSE real-time data for free.
- Some providers expose only end-of-day Indian exchange data on paid tiers. Check current plan coverage before choosing a provider.
- Avoid undocumented Yahoo Finance or broker endpoints in a production recommendation.

## Freshness labels

Use one of:

- `real_time`
- `delayed`
- `end_of_day`
- `latest_reported_quarter`
- `latest_annual_report`
- `user_uploaded`
- `unknown`

Every score must include an `as_of` date and a `freshness` label. If price and fundamentals have different dates, preserve both dates.

## Minimum evidence by mode

### Quick screen

Require identity, sector, price or valuation date, at least two quality fields, one balance-sheet field, and one catalyst or risk field. Label low confidence.

### Detailed review

Require latest annual results, latest quarter, sector-specific quality and balance-sheet fields, valuation, governance check, and source list.

### App-ready result

Require a valid JSON object matching `references/app-handoff.md`. Missing fields remain null.
